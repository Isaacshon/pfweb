---
name: PassionFruits
colors:
  surface: '#faf8ff'
  surface-dim: '#ced9ff'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae1ff'
  on-surface: '#001849'
  on-surface-variant: '#4e4635'
  inverse-surface: '#1a2e5f'
  inverse-on-surface: '#eef0ff'
  outline: '#807662'
  outline-variant: '#d1c5ae'
  surface-tint: '#765a00'
  primary: '#765a00'
  on-primary: '#ffffff'
  primary-container: '#f8c848'
  on-primary-container: '#6e5400'
  inverse-primary: '#f0c041'
  secondary: '#8b4678'
  on-secondary: '#ffffff'
  secondary-container: '#fdaae2'
  on-secondary-container: '#7b396a'
  tertiary: '#ae0099'
  on-tertiary: '#ffffff'
  tertiary-container: '#ffb9e9'
  on-tertiary-container: '#a2008e'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdf96'
  primary-fixed-dim: '#f0c041'
  on-primary-fixed: '#251a00'
  on-primary-fixed-variant: '#5a4400'
  secondary-fixed: '#ffd7ef'
  secondary-fixed-dim: '#ffade5'
  on-secondary-fixed: '#3a0031'
  on-secondary-fixed-variant: '#6f2f5f'
  tertiary-fixed: '#ffd7f0'
  tertiary-fixed-dim: '#fface7'
  on-tertiary-fixed: '#3a0032'
  on-tertiary-fixed-variant: '#850074'
  background: '#faf8ff'
  on-background: '#001849'
  surface-variant: '#dae1ff'
typography:
  display:
    fontFamily: Be Vietnam Pro
    fontSize: 48px
    fontWeight: '800'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Be Vietnam Pro
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Be Vietnam Pro
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Be Vietnam Pro
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Be Vietnam Pro
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  label-caps:
    fontFamily: Be Vietnam Pro
    fontSize: 12px
    fontWeight: '700'
    lineHeight: '1.0'
    letterSpacing: 0.1em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  xs: 4px
  base: 8px
  sm: 12px
  md: 24px
  gutter: 24px
  lg: 48px
  xl: 80px
  container-max: 1280px
---

## Brand & Style
PassionFruits is a vibrant lifestyle brand focused on holistic wellness and communal living. The design style is **Glassmorphic-Modern**, blending organic warmth with digital precision. It evokes a feeling of energy, freshness, and effortless organization through the use of high-saturation accent colors, translucent layers, and soft background blurs. The aesthetic balances professional reliability with a playful, "juicy" personality, utilizing subtle decorative elements like organic sprinkles and curved line flourishes to soften the layout.

## Colors
The palette is centered around the high-contrast pairing of **Brand Yellow** (#f8c848) and **Brand Purple** (#894577). Purple is used for structural depth, typography, and premium sections, while Yellow acts as a high-energy call-to-action color. Surfaces use a cool-toned white/violet spectrum to maintain a clean, airy feel. Semantic roles follow a "fidelity" logic where containers utilize tinted versions of the primary and secondary colors at very low opacities (10-20%) to create colored "zones" without overwhelming the user.

## Typography
The system uses **Be Vietnam Pro** exclusively to maintain a contemporary, friendly, and geometric appearance. Typography is used hierarchically to create "moments": **Display** styles are extra-bold and tight to feel impactful, while **Body** styles prioritize generous line height for readability. **Label-caps** are utilized for metadata and eyebrow headers to provide a structured, organized feel.

## Layout & Spacing
The layout follows a **Fixed-Width Centered** model for marketing content, maxing out at 1280px. A vertical rhythm is established using 24px and 80px increments to separate major sections. Gutters are fixed at 24px. The hero and secondary sections utilize "Organic Clipping," where large background shapes or gradients bleed off the edge of the screen to create a sense of scale and flow.

## Elevation & Depth
Depth is expressed through **Glassmorphism and Tonal Layering**. 
- **Level 1 (Navigation):** Uses a backdrop-blur (blur-xl) with a semi-transparent white fill and a very subtle bottom border.
- **Level 2 (Cards):** Utilizes "Ambient Shadows"—light, diffused shadows (e.g., `rgba(137, 69, 119, 0.05)`) tinted with the secondary color to feel integrated rather than "floating."
- **Level 3 (CTA Buttons):** Uses stronger, colored shadows that match the button's background color to create a glowing, tactile effect.

## Shapes
The shape language is highly rounded and approachable. Standard cards use a 1rem (16px) radius, while interactive elements like buttons and chips are **fully pill-shaped** (rounded-full). Decorative elements often use "organic" radii—extremely large, asymmetrical rounding on one or two corners to mimic the shapes of fruit or smooth river stones.

## Components
- **Buttons:** Primary buttons are pill-shaped, using Brand Yellow with dark text and a colored glow shadow. Secondary buttons are pill-shaped with a 2px Brand Purple outline.
- **Service Cards:** Feature a 4px top border in alternating brand colors (Yellow/Purple), internal padding of 32px, and a subtle lift effect on hover (-8px Y-axis).
- **Chips / Badges:** Pill-shaped with a 10% opacity background of the brand color and matching solid text.
- **Gallery Images:** Images should have an 0.75rem to 1rem border radius and use a masonry-style or staggered column layout to feel "unorganized yet intentional."
- **Navigation Links:** Active states are indicated by a 2px bottom border in Brand Yellow, while hover states transition the text color to Yellow.